extends Module

func _init():
	id = "MyModuleTwerk"
	author = "Me"

	stageScenes = [
		"res://Modules/MyModuleTwerk/Player/StageScene3D/Twerk.tscn",
	]
